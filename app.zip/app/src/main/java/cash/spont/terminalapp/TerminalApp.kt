package cash.spont.terminalapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TerminalApp: Application() {
}