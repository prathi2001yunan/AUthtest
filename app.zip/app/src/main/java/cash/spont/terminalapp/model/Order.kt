package cash.spont.terminalapp.model

data class Order(
    val id: String,
    val total: Double,
    val items: List<OrderItem> = listOf()
)

data class OrderItem(
    var title: String,
    var quantity: Double,
    val total: Double,
    var attributes: List<String> = listOf()
)
