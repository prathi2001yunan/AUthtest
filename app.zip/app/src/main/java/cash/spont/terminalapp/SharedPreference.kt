package cash.spont.terminalapp

import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor

object SharedPreference {
    private var sharedPreferences: SharedPreferences? = null
    private var editor: Editor? = null

    fun getData(context: Context) {
        this.sharedPreferences =
            context.getSharedPreferences("cash.spont.terminalapp.USER_INFO", Context.MODE_PRIVATE)
        editor = sharedPreferences!!.edit()
    }

    fun refreshToken(
      refreshToken: String
    ) {
        editor?.putString("RefreshToken", refreshToken)
        editor?.apply()
    }

    fun getRefreshToken(): String? {
        return sharedPreferences?.getString("RefreshToken", "")
    }

    fun clearAll() {
        editor?.clear()
        editor?.apply()
    }
}