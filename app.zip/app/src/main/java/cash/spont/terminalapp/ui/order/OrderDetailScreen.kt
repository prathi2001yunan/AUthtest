package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cash.spont.terminalapp.R
import cash.spont.terminalapp.model.Order
import cash.spont.terminalapp.model.OrderItem
import cash.spont.terminalapp.model.moneyFormat

@Composable
fun OrderDetailScreen(onTip: () -> Unit) {
    val order = Order(
        "123", 23.45, listOf(
            OrderItem("Ice latte", 1.0, 6.28, listOf<String>("Apple", "Mango", "Orange")),
            OrderItem("Black Coffee", 1.0, 6.28, listOf<String>("Apple", "Mango", "Orange")),
            OrderItem("Ice Cream", 1.0, 6.28, listOf<String>("Apple", "Mango", "Orange")),
            OrderItem("Burger", 1.0, 6.28, listOf<String>("Apple", "Mango", "Orange")),
            OrderItem("Pizza", 1.0, 6.28, listOf<String>("Apple")),
            OrderItem("Cake", 1.0, 6.28, listOf<String>()),
        )
    )
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            OrderDetailLandScapeScreen(order, onTap = { onTip() })
        }

        else -> {
            OrderDetailPortraitScreen(order, onTap = { onTip() })
        }
    }
}

@Composable
private fun OrderDetailLandScapeScreen(order: Order, onTap: () -> Unit) {
    Row(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterVertically) {
        PrintReceipt()
        Scaffold(
            topBar = { OrderDetailTopBar(order) },
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues = paddingValues)
                    .padding(bottom = 20.dp),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                OrderDetailMainContent(order)
                Spacer(modifier = Modifier.size(10.dp))
            }
        }
    }
}


@Composable
private fun OrderDetailPortraitScreen(order: Order, onTap: () -> Unit) {
    Scaffold(topBar = { OrderDetailTopBar(order) },
        bottomBar = { PrintReceipt() }) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues = paddingValues)
                .padding(bottom = 20.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OrderDetailMainContent(order = order)
            Spacer(modifier = Modifier.size(10.dp))
        }
    }
}

@Composable
private fun OrderDetailTopBar(order: Order) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo()
        Spacer(modifier = Modifier.size(10.dp))
        OrderTotalData(order)
    }
}

@Composable
private fun OrderDetailMainContent(order: Order) {
    var count = 0
    Box(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .clip(MaterialTheme.shapes.large)
            .background(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.shapes.large)
    ) {
        LazyColumn(
            Modifier
                .fillMaxWidth()
                .padding(top = 15.dp)
        ) {
            items(order.items) {
                Log.d("count", count.toString())
                Log.d("size", order.items.size.toString())
                OrderItemDisplay(data = it, check = it.title == order.items.last().title)
                if (count == order.items.size) count = 0
            }
        }
    }
}

@Composable
private fun OrderItemDisplay(data: OrderItem, check: Boolean = false) {
    DataRowDisplay(
        quantity = data.quantity,
        name = data.title,
        total = data.total,
        16,
        MaterialTheme.colorScheme.onPrimary
    )
    Spacer(modifier = Modifier.size(5.dp))
    data.attributes.forEach {
        DataRowDisplay(
            quantity = 1.0,
            name = it,
            total = 12.56,
            14,
            MaterialTheme.colorScheme.onPrimaryContainer
        )
        Spacer(modifier = Modifier.size(5.dp))
    }
    Spacer(modifier = Modifier.size(15.dp))
    if (!check) {
        Divider(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            color = MaterialTheme.colorScheme.onSecondary
        )
        Spacer(modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun DataRowDisplay(quantity: Double, name: String, total: Double, size: Int, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        Arrangement.SpaceBetween,
        Alignment.CenterVertically
    ) {
        Row {
            Text(
                text = quantity.toInt().toString(),
                fontSize = size.sp,
                color = color,
                fontWeight = FontWeight.W500
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = name, fontSize = size.sp, color = color, fontWeight = FontWeight.W500)
        }
        Text(
            text = total.toString().replace(".", ","),
            fontSize = size.sp,
            color = color,
            fontWeight = FontWeight.W500
        )
    }
}

@Composable
private fun OrderTotalData(order: Order) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(68.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.primary, MaterialTheme.shapes.medium)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            Arrangement.SpaceBetween,
            Alignment.CenterVertically
        ) {
            Text(
                text = "ORDER TOTAL",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
            Text(
                text = moneyFormat(order.total),
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}