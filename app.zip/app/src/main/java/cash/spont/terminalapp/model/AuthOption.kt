package cash.spont.terminalapp.model

data class AuthOption(
    var id: String,
    val title: String
)
