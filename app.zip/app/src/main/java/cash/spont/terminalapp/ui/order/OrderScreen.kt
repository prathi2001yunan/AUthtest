package cash.spont.terminalapp.ui.order

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import cash.spont.terminalapp.ui.NavRoute
import cash.spont.terminalapp.ui.component.OrderDetailScreen
import cash.spont.terminalapp.ui.component.OrderThankYouScreen
import cash.spont.terminalapp.ui.component.OrderTipScreen
import cash.spont.terminalapp.ui.component.OrderWaitScreen

@Composable
fun OrderScreen(navController: NavHostController) {
    Surface(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val nestedNavController = rememberNavController()
        val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
        if (currentRoute == NavRoute.Order.route) {
            NavHost(
                navController = nestedNavController,
                startDestination = NavRoute.Order.Wait.route
            ) {
                composable(NavRoute.Order.Wait.route) {
                    BackHandler(true) {
                    }
                    OrderWaitScreen(
                        onDetails = { nestedNavController.navigate(NavRoute.Order.Detail.route) }
                    )
                }
                composable(NavRoute.Order.Detail.route) {
                    BackHandler(true) {
                    }
                    OrderDetailScreen(
                        onTip = { nestedNavController.navigate(NavRoute.Order.Tip.route) }
                    )
                }
                composable(NavRoute.Order.Tip.route) {
                    OrderTipScreen(
//                        onThankYou = { nestedNavController.navigate(NavRoute.Order.ThankYou.route) }
                    )
                }
                composable(NavRoute.Order.ThankYou.route) {
                    OrderThankYouScreen()
                }
            }
        }
    }
}