package cash.spont.terminalapp.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import cash.spont.terminalapp.AppConfig
import cash.spont.terminalapp.SharedPreference
import cash.spont.terminalapp.model.AuthCodeResponse
import cash.spont.terminalapp.model.AuthTokenResponse
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.features.RedirectResponseException
import io.ktor.client.features.ServerResponseException
import io.ktor.client.features.json.JsonFeature
import io.ktor.client.features.json.serializer.KotlinxSerializer
import io.ktor.client.features.logging.LogLevel
import io.ktor.client.features.logging.Logging
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.request.post
import io.ktor.client.request.url
import io.ktor.http.Parameters

class ApiService(private var config: AppConfig): Service() {
    private var client: HttpClient = HttpClient(Android) {
        install(Logging) {
            level = LogLevel.ALL
        }
        install(JsonFeature) {
            serializer = KotlinxSerializer()
        }
    }
    private var authToken = ""
    private var refreshToken = ""
    private var expiresIn = 0


    fun hasStoredToken(): Boolean {
     if(SharedPreference.getRefreshToken().isNullOrEmpty()) {
         this.refreshToken = SharedPreference.getRefreshToken().toString()
         return true
     }
        return false
    }

    fun startTimer() {}

    fun stopTimer() {}


    suspend fun getDeviceCode(): AuthResponse<AuthCodeResponse> {
        try {
            val authResponse = AuthRespons
            val response = client.post<AuthCodeResponse> {
                url("${config.auth0Domain}/oauth/device/code")
                body = FormDataContent(
                    Parameters.build {
                        append("client_id", config.auth0ClientId)
                        append("audience", config.auth0Audience)
                        append("scope", "profile email offline_access")
                    }
                )
            }
            val responseData: AuthCodeResponse = response
            print(responseData)
            AuthResponse.Success<AuthCodeResponse>().data = responseData
            return
        } catch (e: RedirectResponseException) {
            println("Error: ${e.response.status.description}")
            return AuthCodeResponse()
        } catch (e: ServerResponseException) {
            println("Error: ${e.response.status.description}")
            return AuthCodeResponse()
        } catch (e: Exception) {
            println("Error: ${e.message}")
            return AuthCodeResponse()
        }
    }
     suspend fun getDeviceToken(deviceCode: String): AuthTokenResponse {
        try {
            val response = client.post<AuthTokenResponse> {
                url("${config.auth0Domain}/oauth/token")
                body = FormDataContent(Parameters.build {
                    append("client_id",config.auth0ClientId)
                    append(
                        "grant_type" , "urn:ietf:params:oauth:grant-type:device_code"
                    )
                    append("device_code" , deviceCode)
                })
            }
            val responseToken: AuthTokenResponse = response
            print(responseToken)
            return responseToken
        } catch (e: RedirectResponseException) {
            println("Message: ${e.response.status.description}")
            return AuthTokenResponse()
        } catch (e: ServerResponseException) {
            println("Message: ${e.response.status.description}")
            return AuthTokenResponse()
        } catch (e: Exception) {
            println("Error: ${e.message}")
            return AuthTokenResponse()
        }
    }
    suspend fun getDeviceNewToken(refreshToken: String): AuthTokenResponse {
        try {
            val response = client.post<AuthTokenResponse> {
                url("${config.auth0Domain}/oauth/token")
                body = FormDataContent(Parameters.build {
                    append("client_id", config.auth0ClientId)
                    append("grant_type", "refresh_token")
                    append(
                        "client_secret", config.auth0Secret
                    )
                    append("refresh_token", refreshToken)
                })
            }
            val responseToken: AuthTokenResponse = response
            print(responseToken)
            return responseToken
        } catch (e: RedirectResponseException) {
            println("Message: ${e.response.status.description}")
            return AuthTokenResponse()
        } catch (e: ServerResponseException) {
            println("Message: ${e.response.status.description}")
            return AuthTokenResponse()
        } catch (e: Exception) {
            println("Error: ${e.message}")
            return AuthTokenResponse()
        }
    }

    override fun onBind(p0: Intent?): IBinder? {
        return null
    }
}


sealed class AuthResponse<T>(
    var data: AuthCodeResponse? = null,
    val message: String? = null
) {
    class Success<T>(data: AuthCodeResponse) : AuthResponse<T>(data)

    class Error<T>(message: String?, data: AuthCodeResponse? = null) : AuthResponse<T>(data, message)

}