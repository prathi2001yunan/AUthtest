package cash.spont.terminalapp.ui.component

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cash.spont.terminalapp.R
import cash.spont.terminalapp.ui.qr.QRCode
import cash.spont.terminalapp.ui.qr.QrCodeProperties

@Composable
fun AuthLoginScreen(onLogin: (url: String) -> Unit) {
    val configuration = LocalConfiguration.current
    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            AuthLoginScreenLandScape(
                onLogin = {url ->
                    onLogin(url)
                }
            )
        }

        else -> {
            AuthLoginScreenPortrait(
                onLogin = {url ->
                    onLogin(url)
                }
            )
        }
    }
}

@Composable
private fun AuthLoginScreenPortrait(onLogin: (url: String) -> Unit) {
    Scaffold(topBar = {
        AuthLoginScreenTopBar()
    }) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(top = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Function to scan the Qrcode
            Spacer(modifier = Modifier.fillMaxHeight(0.05f))
            IsScan()
            Spacer(modifier = Modifier.fillMaxHeight(0.15f))
            Row(
                modifier = Modifier.fillMaxWidth(0.8f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                AuthLoginScreenDivider(modifier = Modifier.weight(0.4f))
            }
            Spacer(modifier = Modifier.fillMaxHeight(0.13f))
            NoScan(onTap = {url -> onLogin(url) })
        }
    }
}

@Composable
private fun AuthLoginScreenLandScape(onLogin: (url: String) -> Unit) {
    Scaffold(topBar = {
        AuthLoginScreenTopBar()
    }) { paddingValues ->
        // rest of the app's UI
        Row(
            Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.5f)
                    .padding(vertical = 15.dp),
                Arrangement.SpaceBetween,
                Alignment.CenterHorizontally
            ) {
                // Function to scan the Qrcode
                IsScan()
            }
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(50.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))
                AuthLoginScreenDivider(
                    modifier = Modifier
                        .height(100.dp)
                        .width(1.dp)
                )
            }
            Spacer(modifier = Modifier.width(30.dp))
            Column(
                Modifier.fillMaxWidth(0.8f), horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.size(20.dp))
                NoScan(onTap = {url -> onLogin(url) })
            }
        }
    }
}

@Composable
private fun AuthLoginScreenTopBar() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo()
    }
}

@Composable
fun IsScan() {
    Column(
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Scan de code en log in op je device.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onPrimary,
            textAlign = TextAlign.Center,
            fontSize = 25.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 70.dp),
            lineHeight = 30.sp,
            fontWeight = FontWeight.W500
        )
        Spacer(modifier = Modifier.size(20.dp))
        Box(
            modifier = Modifier
                .size(170.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.background, RoundedCornerShape(20.dp))
        ) {
            AuthLoginScreenQrCode(
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

@Composable
private fun AuthLoginScreenQrCode(modifier: Modifier) {
    QRCode(
        contents = "www.gmail.com",
        modifier = modifier
            .size(130.dp)
            .clip(RoundedCornerShape(20.dp)),
        qrCodeProperties = QrCodeProperties(
            foreground = MaterialTheme.colorScheme.onPrimary,
            background = Color.Transparent,
        )
    )
}

@Composable
private fun NoScan(onTap: (url: String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 5.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AuthLoginScreenText2(text = "Kan je even niet scannen?", 25, 30)
        Spacer(modifier = Modifier.size(20.dp))
        AuthLoginScreenText1(text = "ga naar:")
        Spacer(modifier = Modifier.size(15.dp))
        AuthLoginScreenButton(onClick = { url ->  onTap(url) })
        Spacer(modifier = Modifier.height(50.dp))
        AuthLoginScreenText1(text = "voer code in")
        AuthLoginScreenText2(text = "xxxx-xxxx", 33)
    }
}

@Composable
private fun AuthLoginScreenText1(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        fontSize = 18.sp,
        fontWeight = FontWeight.W500,
        color = Color.Gray,
    )
}

@Composable
private fun AuthLoginScreenText2(text: String, size: Int, lineHeight: Int = 0) {
    Text(
        text = text,
        fontSize = size.sp,
        fontWeight = FontWeight.W500,
        color = MaterialTheme.colorScheme.onPrimary,
        textAlign = TextAlign.Center,
        lineHeight = lineHeight.sp
    )
}

@Composable
private fun AuthLoginScreenDivider(modifier: Modifier) {
    Divider(
        modifier = modifier, color = Color.Gray
    )
    Text(
        text = "OF",
        style = MaterialTheme.typography.bodyMedium,
        color = Color.Gray,
        fontSize = 25.sp,
        fontWeight = FontWeight.Bold
    )
    Divider(
        modifier = modifier, color = Color.Gray
    )
}

@Composable
private fun AuthLoginScreenButton(onClick: (url: String) -> Unit) {
    val uriHandler = LocalUriHandler.current
    Button(
        onClick = {
            onClick("https://www.google.com/")
            // uriHandler.openUri("https://www.google.com/")
        },
        modifier = Modifier
            .height(40.dp)
            .width(250.dp),
        colors = ButtonDefaults.outlinedButtonColors(MaterialTheme.colorScheme.primary)
    ) {
        Text(
            text = "Go to Spont",
            fontSize = 15.sp,
            color = Color.White
        )
    }
}